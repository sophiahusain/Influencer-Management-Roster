/* 
AUTHORS: Luisa Navarrete and Sophia Husain  
DATE: 2/10/2023  
PURPOSE: Implement singly linked list with another class using templates
*/

#ifndef RANDOMNUMBER_H
#define RANDOMNUMBER_H

//function definition for random number generator 
int randomNum();

#endif